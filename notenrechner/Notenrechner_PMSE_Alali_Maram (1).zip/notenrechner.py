class Notenrechner:
    # Notendurchschnitt-Rechner

    def __init__(self):
        self.module = []  # Liste: [ {"name":..., "note":..., "ects":...}, ... ]

   

    def modul_hinzufuegen(self, name, note, ects):
        self._pruefe_eingaben(name, note, ects)
        self.module.append({"name": name, "note": float(note), "ects": int(ects)})

    def modul_aendern(self, index, note, ects):
      
        self._pruefe_note(note)
        self._pruefe_ects(ects)

        if index < 0 or index >= len(self.module):
            raise ValueError("Index ungueltig.")

        self.module[index]["note"] = float(note)
        self.module[index]["ects"] = int(ects)

    def modul_loeschen(self, index):
        if index < 0 or index >= len(self.module):
            raise ValueError("Index ungueltig.")
        self.module.pop(index)

    def berechne_ects_summe(self):
        summe = 0
        for m in self.module:
            summe = summe + m["ects"]
        return summe

    def berechne_schnitt(self):
        if len(self.module) == 0:
            raise ValueError("Keine Module vorhanden.")

        ects_summe = self.berechne_ects_summe()
        gewichtete_summe = 0

        for m in self.module:
            gewichtete_summe = gewichtete_summe + (m["note"] * m["ects"])

        return gewichtete_summe / ects_summe

 

    def simuliere_zielnote(self, ziel_schnitt, zukunft_ects):
        self._pruefe_note(ziel_schnitt)
        self._pruefe_ects(zukunft_ects)

        if len(self.module) == 0:
            raise ValueError("Keine Module vorhanden.")

        ects_alt = self.berechne_ects_summe()

        sum_alt = 0
        for m in self.module:
            sum_alt = sum_alt + (m["note"] * m["ects"])

        ects_neu = ects_alt + int(zukunft_ects)
        ziel_summe = float(ziel_schnitt) * ects_neu

        benoetigte_note = (ziel_summe - sum_alt) / int(zukunft_ects)

        if benoetigte_note < 1.0 or benoetigte_note > 5.0:
            return None

        return benoetigte_note

   
    def _pruefe_eingaben(self, name, note, ects):
        if name is None or str(name).strip() == "":
            raise ValueError("Modulname darf nicht leer sein.")
        self._pruefe_note(note)
        self._pruefe_ects(ects)

    def _pruefe_note(self, note):
        note = float(note)
        if note < 1.0 or note > 5.0:
            raise ValueError("Note muss zwischen 1.0 und 5.0 liegen.")

    def _pruefe_ects(self, ects):
        ects = int(ects)
        if ects <= 0:
            raise ValueError("ECTS muessen > 0 sein.")
