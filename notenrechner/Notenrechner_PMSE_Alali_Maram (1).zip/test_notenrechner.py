import unittest
from notenrechner import Notenrechner


class TestNotenrechner(unittest.TestCase):

    def setUp(self):
        self.r = Notenrechner()

    def test_FA01_modul_hinzufuegen(self):
        self.r.modul_hinzufuegen("Mathe", 2.3, 6)
        self.assertEqual(len(self.r.module), 1)

    def test_FA03_schnitt_berechnen(self):
        self.r.modul_hinzufuegen("Mathe", 2.0, 6)
        self.r.modul_hinzufuegen("PMSE", 1.0, 3)
        schnitt = self.r.berechne_schnitt()
        self.assertAlmostEqual(schnitt, 1.6666667, places=4)

    def test_FA04_ects_summe(self):
        self.r.modul_hinzufuegen("Mathe", 2.0, 6)
        self.r.modul_hinzufuegen("PMSE", 1.0, 3)
        self.assertEqual(self.r.berechne_ects_summe(), 9)

    def test_FA06_zielnote_erreichbar(self):
        self.r.modul_hinzufuegen("Mathe", 2.0, 6)
        self.r.modul_hinzufuegen("PMSE", 1.0, 3)
        benoetigt = self.r.simuliere_zielnote(2.0, 6)
        self.assertIsNotNone(benoetigt)

    def test_FA07_zielnote_nicht_erreichbar(self):
        self.r.modul_hinzufuegen("Mathe", 5.0, 6)
        benoetigt = self.r.simuliere_zielnote(1.0, 1)
        self.assertIsNone(benoetigt)

    def test_FA09_ungueltige_note(self):
        with self.assertRaises(ValueError):
            self.r.modul_hinzufuegen("Physik", 6.0, 5)

    def test_FA09_ungueltige_ects(self):
        with self.assertRaises(ValueError):
            self.r.modul_hinzufuegen("Physik", 2.0, 0)

    def test_FA02_modul_aendern_und_loeschen(self):
        self.r.modul_hinzufuegen("Mathe", 2.3, 6)
        self.r.modul_aendern(0, 1.7, 6)
        self.assertEqual(self.r.module[0]["note"], 1.7)

        self.r.modul_loeschen(0)
        self.assertEqual(len(self.r.module), 0)


if __name__ == "__main__":
    unittest.main()

